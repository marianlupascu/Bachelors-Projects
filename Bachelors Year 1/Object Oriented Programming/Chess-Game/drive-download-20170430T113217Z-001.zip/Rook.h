#ifndef ROOK_H_INCLUDED
#define ROOK_H_INCLUDED
#include "Pieces.h"

class Rook:public Pieces{

    public:
        Rook(int,int,Color,int,int,int,int);
        std::vector<std::pair<int, int>> getPossibleMoves(int v[8][8],int,int,std::vector<Pieces*>);
};

#endif // ROOK_H_INCLUDED
