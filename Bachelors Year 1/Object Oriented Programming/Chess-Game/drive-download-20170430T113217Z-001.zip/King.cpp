#include "King.h"
#include <iostream>

King::King(int tableColumn,int tableRow,Color color,int textureColumn,int textureRow,int repeat,int moves):
    Pieces(tableColumn,tableRow,color,textureColumn,textureRow,repeat,moves)
    {
}

std::vector<std::pair<int, int>> King::getPossibleMoves(int m_positions[8][8],int x,int y,std::vector<Pieces*> ChessPiece){

    std::vector<std::pair<int, int>> possible_moves;
    int aux_x, aux_y, pos;
    int movesX[8] = {1,-1,0,0,1,1,-1,-1};
    int movesY[8] = {0,0,1,-1,-1,1,1,-1};
    int number_of_moves = 8;
    int selected_color = ChessPiece[m_positions[x][y]] -> getColor();

    for(int i = 0;i < number_of_moves; ++i){
        aux_x = x + movesX[i];
        aux_y = y + movesY[i];
        pos = m_positions[aux_x][aux_y];
        if(aux_x < 8 && aux_y < 8 && aux_x >= 0 && aux_y >= 0){
            if((pos > 0 && ChessPiece[pos] -> getColor() != selected_color) || pos == -1)
                possible_moves.push_back(std::make_pair(aux_x,aux_y));
        }
    }

    return possible_moves;
}

