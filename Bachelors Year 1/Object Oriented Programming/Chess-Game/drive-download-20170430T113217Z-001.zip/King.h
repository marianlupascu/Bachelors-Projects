#ifndef KING_H_INCLUDED
#define KING_H_INCLUDED
#include "Pieces.h"


class King:public Pieces{

    public:
        King(int,int,Color,int,int,int,int);
        std::vector<std::pair<int, int>> getPossibleMoves(int v[8][8],int,int,std::vector<Pieces*>);
};

#endif // KING_H_INCLUDED
